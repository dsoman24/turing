# Turing Machine Simulators
Python is Turing-Complete after all...

### Installation

`pip install turingmachines24`


### How to update:

Change version number

`python setup.py sdist bdist_wheel`

`twine upload --skip-existing dist/*`